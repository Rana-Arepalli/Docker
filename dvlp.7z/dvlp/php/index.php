<?php
$host = 'db'; //sevice name  from docker-compose.yml
$user = 'root';
$password = 'root';
$db = 'test_db';

$conn = new mysqli($host,$user,$password,$db);
if($conn->connect_error)
{
  echo 'connecction failed' . $conn->connect_error;
}

echo 'Succesfully connected to mysql';





?>
